var mysql = require('mysql');
var con = mysql.createConnection({
   host: "localhost",
  user: "root",
  password: "kawabanga123@@",
   database: "killsdevdb"
 });
 con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
   var sql = "CREATE TABLE school_registration (school_name VARCHAR(255), email VARCHAR(255), mobile_number INT(15), address VRCHAR(225)) ";
   con.query(sql, function (err, result) {
    if (err)  throw err;
    console.log("Table created");
  });
});