var mysql = require('mysql');
var con = mysql.createConnection({
   host: "localhost",
  user: "root",
  password: "kawabanga123@@",
   database: "killsdevdb"
 });
 con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
   var sql = "CREATE TABLE enrollment (student_id INT, student_name VARCHAR(225),  mother_name VARCHAR(125),mother_email VARCHAR(125),mother_num INT,father_name VARCHAR(125),father_email VARCHAR(125),father_num INT) ";
   con.query(sql, function (err, result) {
    if (err)  throw err;
    console.log("Table created");
  });
});