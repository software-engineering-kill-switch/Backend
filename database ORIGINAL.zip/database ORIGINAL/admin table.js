var mysql = require('mysql');
var con = mysql.createConnection({
   host: "localhost",
  user: "root",
  password: "kawabanga123@@",
   database: "killsdevdb"
 });
con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
   var sql = "CREATE TABLE admin_registration (first_name VARCHAR(255), last_name VARCHAR(255), email VARCHAR(255), mobile_number INT(15), username VARCHAR(255), user_password PASSWORD(string) ";
   con.query(sql, function (err, result) {
    if (err)  throw err;
    console.log("Table created");
  });
});
