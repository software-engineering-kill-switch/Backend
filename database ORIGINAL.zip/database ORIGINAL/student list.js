var mysql = require('mysql');
var con = mysql.createConnection({
   host: "localhost",
  user: "root",
  password: "kawabanga123@@",
   database: "killsdevdb"
 });
 con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
   var sql = "CREATE TABLE student_list (student_id INT, student_name VARCHAR(225), student_class VARCHAR(225)) ";
   con.query(sql, function (err, result) {
    if (err)  throw err;
    console.log("Table created");
  });
});