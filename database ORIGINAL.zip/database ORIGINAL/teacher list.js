var mysql = require('mysql');
var con = mysql.createConnection({
   host: "localhost",
  user: "root",
  password: "kawabanga123@@",
   database: "killsdevdb"
 });
 con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
   var sql = "CREATE TABLE teacher_list (teacher_id INT, teacher_name VARCHAR(225), teacher_class VARCHAR(225)) ";
   con.query(sql, function (err, result) {
    if (err)  throw err;
    console.log("Table created");
  });
});