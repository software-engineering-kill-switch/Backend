//require packages and set port
const express = require('express');
const port = 3002;
const app = express();
const bodyParser = require('body-parser');
const routes = require('C:/Users/HP/Desktop/express-api/routes/routes');

//Use Node.js body parsing middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true,
}));
routes(app);
//start server
const server = app.listen(port, (error)=>{
    if (error) return console.log(`Error: ${error}`);

    console.log(`Server listening at port ${server.address().port}`);
});

