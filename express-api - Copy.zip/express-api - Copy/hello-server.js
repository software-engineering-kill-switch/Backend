
//build server with node's http module
var http = require('http');
var server=http.createServer();
var port= 3001;

http.createServer(function(req, res){
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end('Hello World!');
}) .listen(8080);

server.listen(port, (error)=>{
    if (error) throw(error);
    console.log(`Server is listening on port ${port}`)
})
