
//some data in JSON format
//no need for static data anymore cause we will be interacting with our db
/*const users = [{
    id:1,
    name: "Richard Hendricks",
    email: "richard@piedpiper.com",
},
{
    id:2,
    name: "Bertram Gilfoyle",
    email: "gilfoyle@piedpiper.com",
},
];
*/

// load the mysql pool connection
const pool = require('C:/Users/HP/Desktop/express-api/data/config');



//moving our app.js GET listener to routes.js
const router = app =>{
    // display all users
    app.get('/users', (request, response) => {
        pool.query('SELECT * FROM users', (error, result) => {
            if (error) throw error;
    
    });
            response.send(result);
        });
    });



//let's say we want to display a single user

    app.get('/users/:id', (request, response) => {
        const id = request.params.id;

        pool.query('SELECT * FROM users WHERE id = ?', id, (error, result) => {
            if (error) throw error;
    
            response.send(result);
        });
    });


//add a new user
app.post('users', (request,response)=>{
    pool.query('INSERT INTO users SET ?', request.body, (error, result)=>{
        if (error) throw error;

        response.status(201).send(`User added with ID: ${result.insertID}`);
    });
});

//updating an existing user
app.put('users/:id', (request,response)=>{
    const id = request.params.id;

    pool.query('UPDATE users SET ? WHERE id= ?', [request.body, id],(error,result)=>{
        if (error) throw error;
        response.send('User updated successfully.');
    });
});

//sending a delete request
app.delete('users/:id', (request, response)=>{
const id = request.params.id;

pool.query('DELETE FROM users WHERE id = ?', id, (error, result)=>{
if (error) throw error;

response.send('User deleted.');
});
});
}
//export the router
module.exports = router;