const mysql = require('mysql');

//setting our database connection credentials
const config = {
    host: 'localhost',
    user: 'root',
    password: 'kawabanga123@@',
    database: 'api',
};
//for efficiency reasons i will create a mysql pool
//creating a mysql pool
const pool = mysql.createPool(config);
module.exports = pool;